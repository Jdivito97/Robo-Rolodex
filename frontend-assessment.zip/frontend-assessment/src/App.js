import BotsDirectory from "./components/directory/BotsDirectory";
import "./App.css";

function App() {
  return (
    <div className="App">
      <BotsDirectory />
    </div>
  );
}

export default App;
